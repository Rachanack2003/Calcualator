package com.servlet.calculator;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CalculatorServlet
 */
@WebServlet("/cs")
public class CalculatorServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int n1=Integer.parseInt(request.getParameter("num1"));
		int n2=Integer.parseInt(request.getParameter("num2"));
		String s=request.getParameter("operation");
		int result=0;
		switch(s) {
		case "Add":
			result=n1+n2;
			break;
		case "Sub":
			result=n1-n2;
			break;
		case "Mul":
			result=n1*n2;
			break;
		case "Div":
			result=n1/n2;
			break;
			
		}
		request.setAttribute("output",result);
		RequestDispatcher rd=request.getRequestDispatcher("calresult.jsp");
		   rd.forward(request, response);
	}

}
